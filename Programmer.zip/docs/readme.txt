# Hi! I'm Sarah Skileth!
# currently this only supports the AT28HC256E-70JU-T on a PA0214C
# feel free to add more 32KiB EEPROMS/EPROMS/PROMs by designing a board using the following footprint:



  |-----------------------------------------------------|
  |pin                          |description          |
  |-----------------------------------------------------|
  | 1                              |display data 7     |
  | 2                              |display data 6     |
  | 3                              |display data 5     |
  | 4                              |display data 4     |
  |5                               |display R/W         |
  |6                               | enable                 |
  |7                               |register select    |
  |8                               | ROM OE               |
  |9                               | GND                     |
  |10                             | +5V                       |
  |11                             | LED 2                    |
  |12                             | LED 1                    |
  |13                             | DATA                     |
  |14                             | CLOCK                   |
  |15                             | GND                       |
  |16                             | +5V                         |
  |-------------------------------------------------------|